<?php

  $result="";
  use PHPMailer\PHPMailer\PHPMailer;
  if (isset($_POST['submit'])){
  require 'vendor/autoload.php';
  
  $mail = new PHPMailer();

  $mail->Host='smtp.gmail.com';
  $mail->Port=587;
  $mail->SMTPAuth=true;
  $mail->SMTPSecure='tls';
  $mail->Username='jbesana99@gmail.com';
  $mail->Password='whitehouse15';

  $mail->setFrom($_POST['email'],$_POST['name']);
  $mail->addAddress('manramrivera@yahoo.com');
  $mail->addReplyTo($_POST['email'],$_POST['name']);

  $mail->isHTML(true);
  //$mail->Subject='Form Submission: '.$_POST ['subject'];
  $mail->Body='<h1 align=center>Name :'.$_POST['name'].'<br>Email: '.$_POST['email']. '<br>Message: '.$_POST['comments']. '</h1>';
  if (!$mail->send()){
    $result="Something went wrong. Please try again.";
  }
  else{
    $result="Thanks ".$_POST['name']."for contacting us. We'll get back to you soon!";
      }
} 

?>

<div id="contacts" class="container-fluid slideanim bg-grey">
      <h2 class="text-center">CONTACT</h2>
      <div class="row">
        <div class="col-sm-5">
          <p>Contact us and we'll get back to you in 24 hours</p>
          <p><span class="glyphicon glyphicon-map-marker"></span>&nbsp;3433, Sardonyx Street, Mabolo, Cebu City, 6000 Cebu, Philippines</p>
          <p><span class="glyphicon glyphicon-phone"></span>&nbsp;+639173289369 / +639176261753</p>
          <p><span class="glyphicon glyphicon-envelope"></span>&nbsp;manramrivera@yahoo.com</p>
        </div>
        <h5 class="text-center text-success"><?=$result; ?></h5>
        <div class="col-sm-7">
          <div class="row">
            <div class="col-sm-6 form-group">
              <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
            </div>
            <div class="col-sm-6 form-group">
              <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
            </div>
          </div>
          <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
          <br>
          <div class="row">
            <div class="form-group">
            <input type="submit" name="submit" id="submit" class="btn btn-primary btn-block" value="Send">
          </div>
            </div>
          </div>
        </div>
      </div>
    </div>