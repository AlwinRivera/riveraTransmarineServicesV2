<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Rivera Transmarine Services | A Domestic Shipping Company in the PHL</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Work Sans' rel='stylesheet'>
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <style>
    </style>
  </head>
  <body id="myPage">
    <!-- NAVIGATION BAR -->
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>                        
          </button>
          <a class="navbar-brand" href="#myPage">RTS</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#about">ABOUT</a></li>
            <li><a href="#portfolio">SERVICES</a></li>
            <li><a href="#contacts">CONTACT</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!--/ NAVIGATION BAR -->

    <!-- JUMBOTRON -->
    <div class="jumbotron text-center">
      <h1 class="mainText">Rivera Transmarine <br>Services</h1> 
      <h2 id="caption">A Domestic Shipping Company in the PHL</h2>
      <br>
      <a href="tel:+63-917-328-9369"><button class="btn btn-success btn-lg">For Inquiry Call Now</button></a>
    </div>
    <!--/ JUMBOTRON -->

    <!-- ABOUT SECTION -->
    <div id="about" class="container-fluid slideanim">
      <div class="row">
        <div class="col-sm-8">
          <h2>About Rivera Transmarine Services</h2>
          <h4>A Domestic Shipping Company in PHL</h4>      
          <p>
            Our fleet of Landing Crafts (LCTs), Tugs and Barges transport bulk and other cargoes all over the Philippines.
            <br>
            We supply shipping services to Cement plants, Power Generation Plants, Mining and to other industries.
            <br>
            Established in 1982, we have over 23 years of experience in Philippine shipping.
          </p>
          <a href="#contacts"><button class="btn btn-success btn-lg">Get in Touch</button></a>
        </div>
        <div class="col-sm-4">
          <span class="glyphicon glyphicon-signal logo"></span>
        </div>
      </div>
    </div>
    <!-- ABOUT SECTION -->

    <!-- SERVICES SECTION -->
    <div id="portfolio" class="container-fluid text-center bg-grey slideanim">
      <h2>OUR SERVICES</h2>
      <br>
      <h4>LCT's &#183; Tugboats &#183; Barges &#183; Cargo Vessels &#183; Charterers &#183; Operators <br> <i>for Sale / Lease / Charter</i></h4>
      <div class="row text-center">
        <div class="col-sm-4">
          <div class="thumbnail panel" data-toggle="modal" data-target="#myModal1"><img src="assets/images/QPEACE.jpg" alt="pipe" width="400" height="300">
          </div>
        </div>
        <div class="col-sm-4">
          <div class="thumbnail panel" data-toggle="modal" data-target="#myModal1"><img src="assets/images/LCT4000DWT.jpg" alt="pipe" width="400" height="300">
          </div>
        </div>
        <div class="col-sm-4">
          <div class="thumbnail panel" data-toggle="modal" data-target="#myModal1"><img src="assets/images/LCT3500DWT(2).jpg" alt="pipe" width="400" height="300">
          </div>
        </div>
      </div>
    </div>

    <!--Modal 1-->
    <div class="modal fade" id="myModal1" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">×</button>
            <h4 class="modal-title">LCT Self Propelled</h4>
          </div>
          <div class="modal-body">
            <div class="container-fluid">
              <img class="center-block" src="assets/images/QPEACE.jpg" alt="pipe" width="65%" height="300">
            <div class="row">
              <p><b>VESSEL PARTICULARS</b></p>
            <p>About LCT Self Propelled</p>
            <p><b>LOA: 69.50M</b></p>
            <ul>
              <li>Breadth: 17M</li>
              <li>Depth: 4.50M</li>
              <li>Loading Capacity: 3,000MT</li>
              <li>Bullwark Height: 60M</li>
              <li>Ramp Lenth:11M</li>
              <li>Ramp Opening Width: 5M</li>
              <li>GRT: 518</li>
              <li>NR5: 350</li>
              <li>M/E Fuel: Diesel 65 Ltr / Hr per engine</li>
              <li>A/E Fuel: Diesel 8 Ltr / Hr per engine</li>
              <li>M/E Oil REV-x HD40: 1 Ltr / Hr per engine</li>
              <li>A/E Oil REV-x HD40: 0.20 Ltr / Hr per engine</li>
            </ul>
            <hr>
            <h5>RELATED VESSELS</h5>
            <a><p></p></a>
            </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
    <!--END OF MODAL 1-->
    <!--/ SERVICES SECTION -->

    <!-- GOOGLE MAPS -->
    <div id="map" style="height:400px;width:100%;"></div>
    <!--/ GOOGLE MAPS -->

    <?php
      $result="";
      use PHPMailer\PHPMailer\PHPMailer;
      if (isset($_POST['submit'])){
        require 'PHPMailer-master/vendor/autoload.php';
        
        $mail = new PHPMailer();
        $mail->SMTPDebug=0;
        $mail->isSMTP(); 
        $mail->Host='smtp.gmail.com';
        $mail->SMTPAuth=true;
        $mail->Username='jbesana99@gmail.com';
        $mail->Password='whitehouse15';
        $mail->SMTPSecure='tls';
        $mail->Port=587;

        $mail->setFrom($_POST['email'],$_POST['name']);
        $mail->addAddress('manramrivera@yahoo.com');
        $mail->addReplyTo($_POST['email'],$_POST['name']);

        $mail->isHTML(true);
        $mail->Subject=$_POST ['subject'];
        $mail->Body='<p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px; text-transform: capitalize;"><b>Name: </b>'.$_POST['name']. '</p>' .'<p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;"><b>Email: </b>'.$_POST['email']. '</p>' . '<p style="font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px; line-height: 1.6;"><b>Message: </b>'.$_POST['message']. '</p>';
        if (!$mail->send()){
          $result="Something went wrong. Please try again.";
        }
        else{
          $result="<div class='alert alert-success alert-dismissible'>
          <a href='#'' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Thanks ".$_POST['name']." for contacting us. Well get back to you soon!</div>";
        }
      } 
    ?>

    <!-- CONTACT SECTION -->  
    <div id="contacts" class="container-fluid slideanim bg-grey">
      <h2 class="text-center">CONTACT</h2>
      <div class="row">
        <div class="col-sm-5">
          <p>Contact us and we'll get back to you in 24 hours</p>
          <p><span class="glyphicon glyphicon-map-marker"></span>&nbsp;3433, Sardonyx Street, Mabolo, Cebu City, 6000 Cebu, Philippines</p>
          <p><span class="glyphicon glyphicon-phone"></span>&nbsp;+639173289369 / +639176261753</p>
          <p><span class="glyphicon glyphicon-envelope"></span>&nbsp;manramrivera@yahoo.com</p>
        </div>
        <div class="col-sm-7">
          <h5><strong><?=$result; ?></strong></h5>
          <form action="" method="post" id="form-box">
            <div class="row">
              <div class="col-sm-6 form-group">
                <input type="text" name="name" class="form-control" placeholder="Enter your name" required>
              </div>
              <div class="col-sm-6 form-group">
                <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
              </div>
            </div>
            <div class="row">
              <div class="col-sm-12 form-group">
                <input type="text" name="subject" class="form-control" placeholder="Enter subject" required>
              </div>
            </div>
            <textarea name="message" id="message" class="form-control" placeholder="Write your message" cols="30" rows="4" required></textarea>
            <br>
            <div class="row">
              <div class="col-sm-12 form-group">
                <input type="submit" name="submit" id="submit" class="btn btn-primary pull-right" value="Send">
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!--/ CONTACT SECTION -->
      
    <!-- FOOTER SECTION -->
    <footer class="container-fluid text-center slideanim">
      <a href="#myPage" title="To Top">
        <span class="glyphicon glyphicon-chevron-up"></span>
      </a>
      <p>Copyright &#169; Rivera Transmarine Services 2018</p>
    </footer>
    <!--/ FOOTER SECTION -->

    <!-- GOOGLE MAPS SCRIPT -->
    <script>
      function initMap() {
        var uluru = {lat: 10.3229367, lng: 123.9170274};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 10,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    <script async defer  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyATaOM-RCOj3wD6wF_BdGZwcVoMLKcl1nw&callback=initMap"></script>
    <!--/ GOOGLE MAPS SCRIPT -->

    <!-- SCROLLSPY SCRIPT -->
    <script>
      $(document).ready(function(){
          $('body').scrollspy({target: ".navbar"});   
      });
    </script>
    <!--/ SCROLLSPY SCRIPT -->

    <!-- SMOOTH SCROLL SCRIPT -->
    <script>
      $(document).ready(function(){
        // Add smooth scrolling to all links in navbar + footer link
        $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

           // Make sure this.hash has a value before overriding default behavior
          if (this.hash !== "") {

            // Prevent default anchor click behavior
            event.preventDefault();

            // Store hash
            var hash = this.hash;

            // Using jQuery's animate() method to add smooth page scroll
            // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
            $('html, body').animate({
              scrollTop: $(hash).offset().top
            }, 900, function(){

              // Add hash (#) to URL when done scrolling (default click behavior)
              window.location.hash= hash;
              });
            } // End if
        });
      })
    </script>
    <!--/ SMOOTH SCROLL SCRIPT -->
  </body>
</html>